<div class="top-header-area">
	<div class="container">
		<div class="row">

			<div class="col-6">
				<div class="top-header-content">
					<a href="#"><i class="fa fa-whatsapp" aria-hidden="true"></i> <span>Whatsapp : 628-2288-777-821</span></a>
					<a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> <span>Email: sales@helenscloudhosting.com</span></a>
				</div>
			</div>
		</div>
	</div>
</div>