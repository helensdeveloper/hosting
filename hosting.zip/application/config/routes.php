<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route = array(
    'default_controller'   	=> 'home',
    '404_override'         	=> '',
    'translate_uri_dashes' 	=> FALSE
);
